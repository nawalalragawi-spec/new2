#!/bin/bash

echo "🚀 جاري بدء عملية الإصلاح والتجهيز..."

# 1. تحميل أدوات Hyperledger Fabric
if [ ! -d "bin" ]; then
    echo "⬇ جاري تحميل الأدوات (Binaries)..."
    curl -sSL https://bit.ly/2ysbOFE | bash -s -- 2.5.9 1.5.7
else
    echo "✅ الأدوات موجودة مسبقاً."
fi

# 2. إصلاح الصلاحيات (في المجلد الحالي وكل ما تحته)
echo "🔓 منح صلاحيات التنفيذ..."
chmod -R +x .

# 3. الدخول لمجلد الشبكة وتشغيلها
cd test-network || { echo "❌ مجلد test-network غير موجود!"; exit 1; }

echo "🧹 تنظيف الشبكة القديمة..."
./network.sh down

echo "🌐 تشغيل الشبكة وإنشاء القناة..."
./network.sh up createChannel

echo "🎉 تم الانتهاء بنجاح!"
